const display = document.querySelector("#display");
const dugmad = document.querySelectorAll("button");
let deadlock = true;
let deadlockforminus = false;
let zvuk = new Audio("boboobob.mp3");

tastatura = document.querySelector("body").addEventListener("keydown", tastatura)

dugmad.forEach(dugme => {
    if(dugme.classList[0]!="special"){
        dugme.addEventListener("click", unos);
    }
})


function tastatura(e){

    cvalue = e.key;

    if(isNaN(cvalue) == false) {
        zvuk.play();
        display.innerHTML+=e.key.toString();
        deadlock = false;
        deadlockforminus = false;
    }
    if(cvalue == "+" || cvalue=="*" || cvalue=="/"){
        zvuk.play();
        if(deadlock==false){
        display.innerHTML+=e.key.toString();
        deadlock = true;
    }
    }
    if(cvalue == "-" && deadlockforminus==false){
        zvuk.play();
        display.innerHTML+=e.key.toString();
        deadlockforminus = true;
        deadlock = true;
    }
    if(cvalue == "Enter" && deadlock == false){
        zvuk.play();
        display.innerHTML= eval(display.innerHTML);
        
    }
}

function unos(e) {
    if(e.target.innerHTML!="C" && e.target.innerHTML!="="){
        zvuk.play();

    if(e.target.classList[0]=="minus"){
        display.innerHTML+=e.target.innerHTML.toString();
            e.target.removeEventListener("click", unos);
            deadlock == true;
            deadlockforminus == true;
            dugmad.forEach(dugme => {
                if(dugme.classList[0]=="special"){
                    dugme.removeEventListener("click", unos);
                }
            });
            
    }

    if(e.target.classList[0]=="special"){
        deadlock == true;
            dugmad.forEach(dugme => {
                if(dugme.classList[0]=="special"){
                    dugme.removeEventListener("click", unos);
                }
            })
            display.innerHTML+=e.target.innerHTML.toString();
    }
        if(e.target.classList[0]!="special" && e.target.classList[0] !="minus"){
            display.innerHTML+=e.target.innerHTML.toString();
            dugmad.forEach(dugme => {
                    dugme.addEventListener("click", unos);
            })
        }
    }
    if (e.target.innerHTML=="C"){
        zvuk.play();
        display.innerHTML = "";
    }

    if(e.target.innerHTML=="="){
        zvuk.play();
        display.innerHTML= eval(display.innerHTML);  
    }
        }

