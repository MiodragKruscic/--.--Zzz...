let ojojoj = undefined;
let sat =  document.querySelector("#sat")
const start = document.querySelector("#start");
start.addEventListener("click", startf, { once: true });
const stop = document.querySelector("#stop");
stop.addEventListener("click", stopf );
const reset = document.querySelector("#reset");
reset.addEventListener("click", resetf);
const pod = document.querySelector(".pod");
pod.addEventListener("click", podf);
const short = document.querySelector(".short");
short.addEventListener("click", shortf);
const long = document.querySelector(".long");
long.addEventListener("click", longf);
let stoper = true;
let zvuk = new Audio("mystery.mp3");
let oj = new Audio("boboobob.mp3");



function stopf(){
    zvuk.pause();
    start.addEventListener("click", startf, { once: true });
    clearInterval(ojojoj);
    stoper = true;
}

function resetf(){
    zvuk.pause();
    start.addEventListener("click", startf, { once: true });
    clearInterval(ojojoj);
    if(pod.classList[1]=="selected"){
        sat.innerHTML="25:00"
    }
    if(short.classList[1]=="selected"){
        sat.innerHTML="05:00"
    }
    if(long.classList[1]=="selected"){
        sat.innerHTML="10:00"
    }
}



function startf(){
    sseconds = "";
    sminutes = "";
    console.log("test");
    stoper = false;
    if(stoper == false){
    ojojoj = setInterval(function(){
        minutes = parseInt(sat.innerHTML.split(":")[0],10);
        seconds = parseInt(sat.innerHTML.split(":")[1],10);
        if(seconds >= 0 && minutes >= 0){
        if(seconds == 0){
            if(minutes > 0){
            oj.play();
            minutes--;
            seconds = 60;}
        }
        if(seconds>0){
        seconds--;
    }   
    sseconds = seconds.toString();
    sminutes = minutes.toString();
    if(minutes<10){
        sminutes = "0"+sminutes;
    }
    if(sseconds < 10){
        sseconds = "0" + sseconds;
    }
        document.title = "⌚️" + "("+sminutes + ":" + sseconds+")" + "        🙋‍♀️🙋‍♀️🙋‍♀️🙋‍♀️🙋‍♀️      ;)"
       sat.innerHTML =  sminutes + ":" + sseconds;
    
       if(minutes==0 && seconds== 0){
        zvuk.play();
        sat.innerHTML= "00:00";
    }
       
    }
    },1000) 
    
}

    
    
}

function podf(e) {
    zvuk.pause();
    start.addEventListener("click", startf, { once: true });
    clearInterval(ojojoj);
    stoper = true;
    sat.innerHTML="25:00"
    this.classList.add("selected");
    short.classList.remove("selected");
    long.classList.remove("selected");
}

function shortf(e) {
    zvuk.pause();
    start.addEventListener("click", startf, { once: true });
    clearInterval(ojojoj);
    stoper = true;
    sat.innerHTML="05:00"
    this.classList.add("selected");
    pod.classList.remove("selected");
    long.classList.remove("selected");
}

function longf(e) {
    zvuk.pause();
    start.addEventListener("click", startf, { once: true });
    clearInterval(ojojoj);
    stoper = true;
    sat.innerHTML="10:00"
    this.classList.add("selected");
    short.classList.remove("selected");
    pod.classList.remove("selected");
}





