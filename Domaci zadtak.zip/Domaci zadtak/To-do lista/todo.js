var form = document.getElementById('addForm');
var itemList = document.getElementById('items');
var filter = document.getElementById('filter');
let dodaj = document.querySelector(".trazi");
let div = document.querySelector("#specialDiv");
let newDiv = document.createElement("div");

filter.addEventListener("keyup", adhd);
filter.addEventListener("blur", adderall);


// Form submit event
form.addEventListener('submit', addItem);
// Delete event
itemList.addEventListener('click', removeItem);
// Filter event
filter.addEventListener('keyup', filterItems);

// Add item
function addItem(e){
  e.preventDefault();

  // Get input value
  var newItem = document.getElementById('item').value;

  // Create new li element
  var li = document.createElement('li');
  // Add class
  li.className = 'list-group-item';
  // Add text node with input value
  li.appendChild(document.createTextNode(newItem));

  // Create del button element
  var deleteBtn = document.createElement('button');

  // Add classes to del button
  deleteBtn.className = 'btn btn-danger btn-sm float-right delete';

  // Append text node
  deleteBtn.appendChild(document.createTextNode('X'));

  // Append button to li
  li.appendChild(deleteBtn);

  // Append li to list
  itemList.appendChild(li);
}

// Remove item
function removeItem(e){
  if(e.target.classList.contains('delete')){
    if(confirm('Are You Sure?')){
      var li = e.target.parentElement;
      itemList.removeChild(li);
    }
  }
}






// Filter Items
function filterItems(e){
  // convert text to lowercase
  var text = e.target.value.toLowerCase();
  // Get lis
  var items = itemList.getElementsByTagName('li');
  // Convert to an array
  Array.from(items).forEach(function(item){
    var itemName = item.firstChild.textContent;
    if(itemName.toLowerCase().indexOf(text) != -1){
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
   
  });
  
}





function adhd(e){
    
    newDiv.classList.add("YES");
    newDiv.style.display="initial";
    newDiv.style.zIndex="900";
    newDiv.style.overflow="visible";
    filter.classList.add("unlimitedRicePudding");
    let aliveItems = document.querySelectorAll(".list-group-item");
    newDiv.innerHTML="";
    setTimeout(function(){
        aliveItems.forEach(item => {
            if(item.style.display=="block"){
            let li = document.createElement("li");
            li.addEventListener("click",epsilonDiesBackwards);
            li.classList.add("test");
            li.innerText = item.innerText.replace("X","");
            li.classList.add("list-group-item");
            newDiv.appendChild(li);
            }
        })
    },0)
    e.target.parentElement.appendChild(newDiv);

}

function epsilonDiesBackwards(e){
    console.log("wow")
    filter.value=e.target.innerText;
}


    function adderall(e){
        setTimeout(function(){
        filter.classList.remove("unlimitedRicePudding");
        newDiv.style.display="none";
        },100)
        
    }
