const kockica = document.querySelectorAll('.kockica');
const tabela = document.querySelector('.tabela');
const podnizoviidemoo = [[0,1,2],[3,4,5],[6,7,8],[0,4,8],[2,4,6],[0,3,6],[1,4,7],[2,5,8]];
const endgame = document.querySelector('.endscreen')
const endgameh = document.querySelector('.endscreen h1')
console.log(endgameh)
let end = false;
let totalnonasumicanbrojkojiuopstenesluzinicemu = 1;
let xskor = 0;
let oskor = 0;
let iksskor = document.querySelector('#iksskor');
let oksskor = document.querySelector('#oksskor');

//MIjenja boju pozadine i boje onih linija
function changeColor() {
    if(tabela.classList[1] == "tiks"){
    tabela.style.backgroundColor= "orange";
    kockica.forEach(polje => {
        polje.style.borderColor= "green";
    })

}
    else{
        tabela.style.backgroundColor= "green";
    kockica.forEach(polje => {
        polje.style.borderColor= "orange";
    })
    }
}


//DODA KLIK MISA
kockica.forEach(polje => {
    polje.addEventListener('click', handleClick, { once: true })
})



//MIJENJA POTEZ LAGANOO 
function changeTurn(){
    if(tabela.classList[1]=="tiks"){
        tabela.classList.remove("tiks");
        tabela.classList.add("toks");
    } 
    else{
        tabela.classList.remove("toks")
        tabela.classList.add("tiks")
    }
}

//STVALJA IKS ILI OKS (nije predsenik rusije)
function putIN(e){
        if(tabela.classList[1]=="tiks"){
            e.target.classList.add("oks")
        } 
        else{
            e.target.classList.add("iks")
        }
    }
    

 //DETEKTUJE DOBITNE KOMBINACIJE   
function wincombo(){
    for(let i = 0; i<podnizoviidemoo.length;i++){
        if(kockica[podnizoviidemoo[i][0]].classList[1] != undefined && kockica[podnizoviidemoo[i][0]].classList[1] == kockica[podnizoviidemoo[i][1]].classList[1] && kockica[podnizoviidemoo[i][0]].classList[1] == kockica[podnizoviidemoo[i][2]].classList[1] ){
            end = true;
        }
    }
}

//ODLUCUJE KO JE DOBTNIK
function winner(){
    if(end && tabela.classList[1]=="toks"){
        xskor++;
        endgameh.innerHTML = "X wins!";
        endgame.style.display = "flex";
    }
    else if (end && tabela.classList[1]=="tiks"){
        oskor++;
        endgameh.innerHTML = "O wins!"
        endgame.style.display = "flex";
    }


}


//SVE STO SE DESI KAD SE KLIKNE
function handleClick(e) {
    changeTurn();
    putIN(e);
    wincombo();
    winner();
    changeColor();
    totalnonasumicanbrojkojiuopstenesluzinicemu++;
    iksskor.innerHTML = "X : " + xskor;
    oksskor.innerHTML = "O : " + oskor;
    if(totalnonasumicanbrojkojiuopstenesluzinicemu > 9 && end == false){
        endgameh.innerHTML = "DRAW!"
        endgame.style.display = "flex";
    }
}



//SAMO IME KAZE
function restart() {
    end = false;
    for(let i = 0; i<9; i++){
        kockica[i].classList.remove("iks")
        kockica[i].classList.remove("oks")
    }
    endgame.style.display= "none";
    kockica.forEach(polje => {
        polje.addEventListener('click', handleClick, { once: true })
    })
    totalnonasumicanbrojkojiuopstenesluzinicemu = 1;
    tabela.classList.remove("tiks");
    tabela.classList.remove("toks");
    tabela.classList.add("tiks");
    tabela.style.backgroundColor = "orange";
    kockica.forEach(polje => {
        polje.style.borderColor= "green";
    });
}


