let smallerOnTheOutside = false;
let i=1;
let a=2;
let slike = document.querySelectorAll("li");
let slikeimg = document.querySelectorAll(".slider img");
console.log(slikeimg);
const manja = document.querySelector(".theFirstOne").addEventListener("click" ,manjaf);
const veca = document.querySelector(".theSecondOne").addEventListener("click", vecaf);
const vesna = document.querySelector("body");
const desna = document.querySelector("body").addEventListener("keydown",desno);
const iks = document.querySelector("#close").addEventListener("click" ,itsTimeToStop)
const kiks = document.querySelector("#close")

let b = 0;
let small = 3;
let big = 3;
let poveca=3;
let smanjuje =3;

function itsTimeToStop(e){
   smallerOnTheOutside = false;
   slike[i].style.order="2";
    slike[b].style.order="1";
    slike[a].style.order="3";
     slikeimg[i].style.display="initial";
    slikeimg[b].style.display="initial";
    slikeimg[a].style.display="initial";
     slikeimg[i].classList.add("selected");
     slikeimg[i].classList.remove("open");
     kiks.style.display="none";
}

slikeimg.forEach(slike=>{
    slike.addEventListener("click",biggerOnTheInside);
})


function biggerOnTheInside(e){
    if(slikeimg[i]==e.target){
    kiks.style.display="initial";
    smallerOnTheOutside=true;
    slikeimg[i].style.display="initial";
    slikeimg[i].classList.add("open");
    slikeimg[a].style.display="none";
    slikeimg[b].style.display="none";
}
}


function desno(e){
    if(e.keyCode == 39){
        vecaf();
    }
    if(e.keyCode == 37){
        manjaf();
    }
}


function vecaf(){
    i++;
    i = i%slike.length;
    b++;
    b = b%slike.length;
    a++;
    a = a%slike.length;
    for(let h = 0; h<slikeimg.length;h++){

        slikeimg[h].classList.remove("selected");
        slikeimg[h].style.order="none";
        slikeimg[h].style.display="none";
        slikeimg[h].classList.remove("open");
        
        }
        if(smallerOnTheOutside==false){
        slike[i].style.order="2";
        slike[b].style.order="1";
        slike[a].style.order="3";
        slikeimg[i].style.display="initial";
        slikeimg[b].style.display="initial";
        slikeimg[a].style.display="initial";
        slikeimg[i].classList.add("selected");}
        else{
            slikeimg[i].style.display="initial";
            slikeimg[i].classList.add("open");
        }
        
}

function manjaf() {
    i--;
    a--;
    b--;
    if(b<0){
        b=slike.length-1;
    }
    if(a<0){
        a=slike.length-1;
    }
    manjapromjenjiva = i;
    if(i<0){
        i=slike.length-1;
    }

    for(let h = 0; h<slikeimg.length-1;h++){    
        slikeimg[h].classList.remove("selected");
        slikeimg[slike.length-1].classList.remove("selected");
        }

        for(let h = 0; h<slikeimg.length;h++){

            slikeimg[h].classList.remove("selected");
            slikeimg[h].style.order="none";
            slikeimg[h].style.display="none";
            slikeimg[h].classList.remove("open");
            }
            if(smallerOnTheOutside==false){
            slike[i].style.order="2";
            slike[b].style.order="1";
            slike[a].style.order="3";
            slikeimg[i].style.display="initial";
            slikeimg[b].style.display="initial";
            slikeimg[a].style.display="initial";
            slikeimg[i].classList.add("selected");}
            else{
                slikeimg[i].style.display="initial";
                slikeimg[i].classList.add("open");
            }
}


//SAD VIDIM DA SAM MOGAO MASU DA SKRATIM KOD ALI MUKA MI JE PA NECU :P