let tijelo = document.querySelector("body")
let firstNumber = document.querySelector("#firstNumber");
let second = document.querySelector(".second");
let first = document.querySelector(".first");
let palindromT = false;
let palindromtxt = document.querySelector(".palindromtext")
let palindromh = document.querySelector(".palindromtext h3")
let hdva = document.querySelector("h2");
let giant = new Audio("Giant Steps.mp3");

//STVARANJE ELEMNTA KOJEG UBACUJEM (onih kocikca)

function createElement(){
let minus = document.createElement("img");
minus.classList.add("minus");
minus.addEventListener("click",minusf);
minus.setAttribute("width", "30em");
let plus = document.createElement("img");
plus.classList.add("plus");
plus.addEventListener("click",plusf);
plus.setAttribute("width", "20em");
let minusDiv = document.createElement("div");
let kockica = document.createElement("input");
kockica.classList.add("kockica");
kockica.addEventListener("keyup", validator);
kockica.setAttribute("maxlength", "1");
kockica.setAttribute("type", "text");
minusDiv.classList.add("minusDiv");
minus.src = "minus.svg";
plus.src = "plus.svg";
let kockice = document.createElement("div");
kockice.classList.add("kockice");
minusDiv.appendChild(kockica);
minusDiv.appendChild(minus);
kockice.appendChild(minusDiv);
kockice.appendChild(plus);
kockice.addEventListener("click",palindrom);
kockice.addEventListener("keyup",palindrom);
return kockice;
}

 
//da ne unese neko broj!(ILI NEKI DRUGI ZNAK!)
function validator(e){
    if(e.target.value != " "){
    let regex = /[^a-z]/gi;
    e.target.value = e.target.value.replace(regex, "")}
}



//provjerava jeli izraz palindrom
function palindrom(e){
    let niz = [];
    let obrnutniz = [];
    let input = document.querySelectorAll(".second input");
    for(let i = 0;i<input.length;i++){
            niz.push(input[i].value);
    }
    for(let i = input.length-1;i>-1;i--){
        obrnutniz.push(input[i].value);
}
    if (niz.toString().replace(/,/g,"").replace(/\s/g,"").toLowerCase() == obrnutniz.toString().replace(/,/g,"").replace(/\s/g,"").toLowerCase() && niz.toString().replace(/,/g,"").replace(/\s/g,"").length>1){
        palindromT = true;
        palindromh.innerHTML = "RIJEČ JE PALINDROM ✽-( ˘▽˘ )/✽";
        palindromh.classList.remove("false");
        palindromh.classList.add("true");
    }
    else {
        palindromh.innerHTML = "RIJEČ NIJE PALINDROM (╯°□°)";
        palindromh.classList.remove("true");
        palindromh.classList.add("false");
    }

}




//DAJE FUNKCIJU MINUS ZNAKU NA KOCKICI
function minusf(e, kockice){
    e.target.parentNode.parentNode.parentNode.removeChild(e.target.parentNode.parentNode);
    palindrom();
}


//DAJE F-ju PLUS ZNAKU
function plusf(e,kockice){
    e.target.parentNode.parentNode.insertBefore(createElement(),e.target.parentNode.nextSibling);
    palindrom();
}


tijelo.addEventListener("keydown", handleClick);


//mijenja sirinu prve kockice 
function changeWidthforfirstNUm(e){
    if(e.keyCode != 8){
    firstNumber.style.width= firstNumber.value.length + 1 +"em";
    }
    else {
        firstNumber.style.width= firstNumber.value.length - 1 +"em";
    }
}



function handleClick(e){
    changeWidthforfirstNUm(e);
};



function start(){
    giant.play();
    let n = firstNumber.value;
    palindromtxt.style.display = "initial"
    if(isNaN(n) == false && n != " " && n != "" && n > 0){
        tijelo.removeEventListener("keydown",handleClick);
        first.style.display = "none"
        for(let i=0;i<n;i++) {
        second.appendChild(createElement());
        }
    }
    else {
        hdva.style.opacity="1"
    }
    
}






